# -*- coding: utf-8 -*-

import time

__version__ = (1, 0, 0, 'alpha', int(time.time() / 100))
